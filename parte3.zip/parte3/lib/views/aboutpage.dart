import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Acerca de'),
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundImage: AssetImage('assets/profile.jpg'),
              radius: 80,
            ),
            SizedBox(height: 20),
            Text(
              'Scarlette Diaz',
              style: TextStyle(fontSize: 26),
            ),
            SizedBox(height: 10),
            Text(
              'Correo electrónico: 14scarlette@gmail.com',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 10),
            Text(
              'Teléfono: 829-648-8524',
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
